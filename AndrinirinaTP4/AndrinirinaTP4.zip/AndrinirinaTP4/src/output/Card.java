package output;
public interface Card{
}
package output;
public enum Color{
   CLUB, DIAMOND, HEART, SPADE
}
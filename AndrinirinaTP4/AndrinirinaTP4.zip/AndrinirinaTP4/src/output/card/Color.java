package output.card;
public enum Color{
   CLUB, DIAMOND, HEART, SPADE
}
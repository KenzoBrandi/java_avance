package output.card;
public interface Card{
}